Simple programming language Ask ChatGpt Ai Pocket on how to use it 
